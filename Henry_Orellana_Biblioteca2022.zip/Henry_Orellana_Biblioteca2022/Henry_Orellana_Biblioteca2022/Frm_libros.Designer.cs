﻿namespace Henry_Orellana_Biblioteca2022
{
    partial class Frm_libros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSalirLibros = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtIDCate = new System.Windows.Forms.TextBox();
            this.txtIDAut = new System.Windows.Forms.TextBox();
            this.txtTitulo = new System.Windows.Forms.TextBox();
            this.txtIDLibros = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gridDatosLibros = new System.Windows.Forms.DataGridView();
            this.btnModificarLibros = new System.Windows.Forms.Button();
            this.btnEliminarLibros = new System.Windows.Forms.Button();
            this.btnAgregarLibros = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosLibros)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSalirLibros
            // 
            this.btnSalirLibros.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnSalirLibros.Location = new System.Drawing.Point(357, 320);
            this.btnSalirLibros.Name = "btnSalirLibros";
            this.btnSalirLibros.Size = new System.Drawing.Size(79, 33);
            this.btnSalirLibros.TabIndex = 85;
            this.btnSalirLibros.Text = "Salir";
            this.btnSalirLibros.UseVisualStyleBackColor = true;
            this.btnSalirLibros.Click += new System.EventHandler(this.btnSalirLibros_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtIDCate);
            this.groupBox1.Controls.Add(this.txtIDAut);
            this.groupBox1.Controls.Add(this.txtTitulo);
            this.groupBox1.Controls.Add(this.txtIDLibros);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(22, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(403, 287);
            this.groupBox1.TabIndex = 80;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos de producto";
            // 
            // txtIDCate
            // 
            this.txtIDCate.Location = new System.Drawing.Point(197, 213);
            this.txtIDCate.Name = "txtIDCate";
            this.txtIDCate.Size = new System.Drawing.Size(111, 20);
            this.txtIDCate.TabIndex = 15;
            // 
            // txtIDAut
            // 
            this.txtIDAut.Location = new System.Drawing.Point(197, 157);
            this.txtIDAut.Name = "txtIDAut";
            this.txtIDAut.Size = new System.Drawing.Size(111, 20);
            this.txtIDAut.TabIndex = 14;
            // 
            // txtTitulo
            // 
            this.txtTitulo.Location = new System.Drawing.Point(140, 108);
            this.txtTitulo.Name = "txtTitulo";
            this.txtTitulo.Size = new System.Drawing.Size(168, 20);
            this.txtTitulo.TabIndex = 13;
            // 
            // txtIDLibros
            // 
            this.txtIDLibros.Enabled = false;
            this.txtIDLibros.Location = new System.Drawing.Point(197, 62);
            this.txtIDLibros.Name = "txtIDLibros";
            this.txtIDLibros.Size = new System.Drawing.Size(111, 20);
            this.txtIDLibros.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(83, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "ID_Categoria:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(83, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "ID_Autor:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(83, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Titulo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(83, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "ID_Libro:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gridDatosLibros);
            this.groupBox2.Location = new System.Drawing.Point(431, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(517, 287);
            this.groupBox2.TabIndex = 84;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tabla producto en la BD";
            // 
            // gridDatosLibros
            // 
            this.gridDatosLibros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosLibros.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.gridDatosLibros.Location = new System.Drawing.Point(6, 19);
            this.gridDatosLibros.MultiSelect = false;
            this.gridDatosLibros.Name = "gridDatosLibros";
            this.gridDatosLibros.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosLibros.Size = new System.Drawing.Size(505, 262);
            this.gridDatosLibros.TabIndex = 0;
            this.gridDatosLibros.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridDatosLibros_CellValueChanged);
            this.gridDatosLibros.Click += new System.EventHandler(this.gridDatosLibros_Click);
            // 
            // btnModificarLibros
            // 
            this.btnModificarLibros.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnModificarLibros.Location = new System.Drawing.Point(122, 320);
            this.btnModificarLibros.Name = "btnModificarLibros";
            this.btnModificarLibros.Size = new System.Drawing.Size(99, 33);
            this.btnModificarLibros.TabIndex = 83;
            this.btnModificarLibros.Text = "Modificar";
            this.btnModificarLibros.UseVisualStyleBackColor = true;
            this.btnModificarLibros.Click += new System.EventHandler(this.btnModificarLibros_Click);
            // 
            // btnEliminarLibros
            // 
            this.btnEliminarLibros.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnEliminarLibros.Location = new System.Drawing.Point(241, 320);
            this.btnEliminarLibros.Name = "btnEliminarLibros";
            this.btnEliminarLibros.Size = new System.Drawing.Size(89, 33);
            this.btnEliminarLibros.TabIndex = 82;
            this.btnEliminarLibros.Text = "Eliminar";
            this.btnEliminarLibros.UseVisualStyleBackColor = true;
            this.btnEliminarLibros.Click += new System.EventHandler(this.btnEliminarLibros_Click);
            // 
            // btnAgregarLibros
            // 
            this.btnAgregarLibros.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnAgregarLibros.Location = new System.Drawing.Point(7, 320);
            this.btnAgregarLibros.Name = "btnAgregarLibros";
            this.btnAgregarLibros.Size = new System.Drawing.Size(92, 33);
            this.btnAgregarLibros.TabIndex = 81;
            this.btnAgregarLibros.Text = "Agregar";
            this.btnAgregarLibros.UseVisualStyleBackColor = true;
            this.btnAgregarLibros.Click += new System.EventHandler(this.btnAgregarLibros_Click);
            // 
            // Frm_libros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(961, 450);
            this.Controls.Add(this.btnSalirLibros);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnModificarLibros);
            this.Controls.Add(this.btnEliminarLibros);
            this.Controls.Add(this.btnAgregarLibros);
            this.Name = "Frm_libros";
            this.Text = "Frm_libros";
            this.Load += new System.EventHandler(this.Frm_libros_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosLibros)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSalirLibros;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtIDCate;
        private System.Windows.Forms.TextBox txtIDAut;
        private System.Windows.Forms.TextBox txtTitulo;
        private System.Windows.Forms.TextBox txtIDLibros;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView gridDatosLibros;
        private System.Windows.Forms.Button btnModificarLibros;
        private System.Windows.Forms.Button btnEliminarLibros;
        private System.Windows.Forms.Button btnAgregarLibros;
    }
}