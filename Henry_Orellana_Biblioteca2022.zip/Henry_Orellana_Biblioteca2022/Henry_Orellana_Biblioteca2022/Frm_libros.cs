﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Henry_Orellana_Biblioteca2022
{
    public partial class Frm_libros : Form
    {
        Clases.Transacciones T = new Clases.Transacciones();
        Clases.Libros L = new Clases.Libros();
        public Frm_libros()
        {
            InitializeComponent();
        }

        private void Frm_libros_Load(object sender, EventArgs e)
        {
            cargar();
        }
        private void cargar()
        {
            gridDatosLibros.DataSource = T.consultar("Libros");
        }

        private void btnAgregarLibros_Click(object sender, EventArgs e)
        {
            L.titulo = txtTitulo.Text;
            L.id_autor = int.Parse(txtIDAut.Text);
            L.id_categoria = int.Parse(txtIDCate.Text);
            T.insertar(L, "Libros");
            cargar();
        }

        private void btnModificarLibros_Click(object sender, EventArgs e)
        {
            L.titulo = txtTitulo.Text;
            L.id_autor = int.Parse(txtIDAut.Text);
            L.id_categoria = int.Parse(txtIDCate.Text);
            L.id_libro = int.Parse(txtIDLibros.Text); //IMPORTANTE
            T.modificar(L, "Libros");
            cargar();
        }

        private void btnEliminarLibros_Click(object sender, EventArgs e)
        {
            int fila;
            string valor;
            bool intento;
            fila = gridDatosLibros.CurrentRow.Index;
            gridDatosLibros.Rows[fila].Selected = true;

            valor = gridDatosLibros.SelectedCells[0].Value.ToString();

            if (MessageBox.Show("¿Seguro que quieres eliminar el registro?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                intento = T.eliminar("Libros", "id_libro", valor);
                if (intento == true)
                {
                    MessageBox.Show("Los datos se han eliminado");
                }
            }

            else
            {
                MessageBox.Show("Los datos no se han eliminado");
            }

            cargar();
        }

        private void btnSalirLibros_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gridDatosLibros_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void gridDatosLibros_Click(object sender, EventArgs e)
        {
            this.txtIDLibros.Text = this.gridDatosLibros.SelectedRows[0].Cells[0].Value.ToString();
            this.txtTitulo.Text = this.gridDatosLibros.SelectedRows[0].Cells[1].Value.ToString();
            this.txtIDAut.Text = this.gridDatosLibros.SelectedRows[0].Cells[2].Value.ToString();
            this.txtIDCate.Text = this.gridDatosLibros.SelectedRows[0].Cells[3].Value.ToString();
        }
    }
}
