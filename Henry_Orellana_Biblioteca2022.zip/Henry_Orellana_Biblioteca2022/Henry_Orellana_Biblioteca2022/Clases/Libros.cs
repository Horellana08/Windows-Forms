﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henry_Orellana_Biblioteca2022.Clases
{
    class Libros
    {
        public int id_libro;
        public string titulo;
        public int id_autor;
        public int id_categoria;

        public Libros(string titu, int idaut, int idcate)
        {
            this.titulo = titu;
            this.id_autor = idaut;
            this.id_categoria = idcate;
        }

        public Libros()
        {
           
        }
    }
}
