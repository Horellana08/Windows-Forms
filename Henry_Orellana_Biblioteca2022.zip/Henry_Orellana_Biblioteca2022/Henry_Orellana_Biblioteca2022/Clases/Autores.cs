﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henry_Orellana_Biblioteca2022.Clases
{
    class Autores
    {
        public int id_autor;
        public string nombre_autor;
        public string apellidos;
        public string nacionalidad;
        public string telefono;

        public Autores(string nom, string ape, string nacio, string telef)
        {
            this.nombre_autor = nom;
            this.apellidos = ape;
            this.nacionalidad = nacio;
            this.telefono = telef;
        }

        public Autores()
        {
            
        }
    }
}
