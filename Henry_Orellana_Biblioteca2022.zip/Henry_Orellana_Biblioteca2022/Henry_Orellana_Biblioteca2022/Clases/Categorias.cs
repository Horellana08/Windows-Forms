﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henry_Orellana_Biblioteca2022.Clases
{
 class Categorias
    {
        public int id_categoria;
        public string nombre_categoria;

        public Categorias(string NomCate)
        {
            this.nombre_categoria = NomCate;
        }
        public Categorias()
        {
        }
    }
}
