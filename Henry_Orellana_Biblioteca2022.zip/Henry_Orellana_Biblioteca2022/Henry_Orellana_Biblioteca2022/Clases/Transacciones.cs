﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Librerias necesarias para trabajar con conexión a SQL
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace Henry_Orellana_Biblioteca2022.Clases
{
   class Transacciones
    {
        string sql = ""; //para guardar las sql's
        SqlConnection con = new SqlConnection(); //para conectar
        SqlCommand cmd = new SqlCommand();//para ejecutar sql's
        //ESTOS OBJETOS, DEBERÍA HABER UNO POR CADA TABLA DE LA BD
        Libros L = new Libros();
        Autores A = new Autores();
        Categorias C = new Categorias();

        // Constructor que inicia la cadena de conexión
        public Transacciones()
        {
            this.con.ConnectionString = "Data Source=CDS1-PC32;Initial Catalog=biblioteca2022;Integrated Security=True";
        }

        //Método para llenar el datgridview
        public DataTable consultar(string tabla)
        {
            DataTable datos = new DataTable();
            //variable para que usa para llenar de el datasource al datatable
            SqlDataAdapter adapter = new SqlDataAdapter();
            //Dependiendo de la tabla que se manda a llamar, se crea la sql a ejecutar
            switch (tabla)
            {
                case "Autores":
                    this.sql = "select * from Autores";
                    break;

                case "Categorias":
                    this.sql = "select * from Categorias";
                    break;

                case "Libros":
                    this.sql = "select * from Libros";
                    break;

                case "otra_tabla":
                    this.sql = "select * from otra_tabla";
                    break;

                default:
                    MessageBox.Show("Error de programación, tabla no existe!");
                    break;
            }
            //Conociendo la sql a ejecutar, ejecutamos
            try
            {
                this.con.Open(); //se abre la conexion
                //se carga el adapter y de una se conecta
                adapter = new SqlDataAdapter(this.sql, con.ConnectionString);
                adapter.Fill(datos);//llena datos con el resultado de la consulta 
            }
            catch (SqlException error)
            {
                MessageBox.Show("Ocurrio el siguiente error de SQL:" + error.Message);
            }
            finally
            {
                this.con.Close();
            }
            return datos;

        }
        //método personalizado para ejecutar  sql´s de cada transaccion
        private bool ejecutar(string sql)
        {
            //Este método ejecuta cualquier sql y retorna true o false dependiendo si se da o no
            //la sql es la que viene como parámetro
            try
            {
                this.cmd.CommandText = sql;// Definimos el sql a ejecutar
                this.cmd.Connection = this.con;// el cmd toma la configuracion de conexion
                this.cmd.Connection.Open();//se abre ña conexión
                this.cmd.ExecuteNonQuery();// se ejecuta la sql guardada en cmd
                return true;
            }
            catch (SqlException error)
            {
                MessageBox.Show("Error de SQL:" + error.Message);
                return false;

            }
            finally
            {
                this.cmd.Connection.Close();//se cierra la conexion activa
            }
        }

        public bool insertar(object objDatos, string tabla)
        {
            bool resp;
            //Dependiendo de la tabla se genera la sql
            switch (tabla)
            {
                case "Autores":
                    this.A = (Autores)objDatos;// casting
                    this.sql = "insert into Autores(nombre_autor, apellidos, nacionalidad, telefono) values('" + A.nombre_autor + "', '" + A.apellidos + "', '" + A.nacionalidad + "', '" + A.telefono + "')";
                    break;

                case "Categorias":
                    this.C = (Categorias)objDatos;// casting
                    this.sql = "insert into Categorias(nombre_categoria) values('" + C.nombre_categoria + "')";
                    break;

                case "Libros":
                    this.L = (Libros)objDatos;// casting
                    this.sql = "insert into Libros(titulo, id_autor, id_categoria) values('" + L.titulo + "', '" + L.id_autor + "', '" + L.id_categoria + "')";
                    break;

                case "otraTabla":
                    //this.otroObjeto = (OtraClase)objDatos;//casting
                    this.sql = "insert into otraTabla values....";
                    break;
                default:
                    MessageBox.Show("No se ingresaron datos, error de programación");
                    break;
            }

            if (ejecutar(this.sql))
            {
                resp = true;
                MessageBox.Show("Registro agregado EXITOSAMENTE!!");
            }
            else
            {
                resp = false;
            }

            return resp;
        }
        public bool modificar(object objDatos, string tabla)
        {
            switch (tabla)
            {
                case "Autores":
                    this.A = (Autores)objDatos;
                    this.sql = "update Autores set nombre_autor= '" + A.nombre_autor + "', apellidos= '" + A.apellidos + "', nacionalidad= '" + A.nacionalidad + "', telefono= '" + A.telefono + "' where id_autor= " + A.id_autor;
                    break;

                case "Categorias":
                    this.C = (Categorias)objDatos;
                    this.sql = "update Categorias set nombre_categoria= '" + C.nombre_categoria + "' where id_categoria= " + C.id_categoria;
                    break;

                case "Libros":
                    this.L = (Libros)objDatos;
                    this.sql = "update Libros set titulo= '" + L.titulo + "', id_autor= '" + L.id_autor + "', id_categoria= '" + L.id_categoria + "' where id_libro= " + L.id_libro;
                    break;

                default:
                    MessageBox.Show("No se ingresaron datos, error de programación");
                    break;
            }
            if (ejecutar(this.sql))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool eliminar(string tabla, string campoID, string valorID)
        {
            string sql = " delete from " + tabla + " where " + campoID + " = " + valorID;
            if (ejecutar(sql))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

