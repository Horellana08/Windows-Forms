﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Henry_Orellana_Biblioteca2022
{
    public partial class Frm_categoria : Form
    {
        Clases.Transacciones TR = new Clases.Transacciones();
        Clases.Categorias C = new Clases.Categorias();
        public Frm_categoria()
        {
            InitializeComponent();
        }

        private void Frm_categoria_Load(object sender, EventArgs e)
        {
            cargar();
        }
        private void cargar()
        {
            gridDatosCategoria.DataSource = TR.consultar("Categorias");
        }

        private void btnAgregarCategoria_Click(object sender, EventArgs e)
        {
            C.nombre_categoria = txtNombreCategoria.Text;
            TR.insertar(C, "Categorias");
            cargar();
        }

        private void btnModificarCategoria_Click(object sender, EventArgs e)
        {
            C.nombre_categoria = txtNombreCategoria.Text;
            C.id_categoria = int.Parse(txtIDCategoria.Text); //IMPORTANTE
            TR.modificar(C, "Categorias");
            cargar();
        }

        private void btnEliminarCategoria_Click(object sender, EventArgs e)
        {
            int fila;
            string valor;
            bool intento;
            fila = gridDatosCategoria.CurrentRow.Index;
            gridDatosCategoria.Rows[fila].Selected = true;

            valor = gridDatosCategoria.SelectedCells[0].Value.ToString();

            if (MessageBox.Show("¿Seguro que quieres eliminar el registro?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                intento = TR.eliminar("Categorias", "id_categoria", valor);
                if (intento == true)
                {
                    MessageBox.Show("Los datos se han eliminado");
                }
            }

            else
            {
                MessageBox.Show("Los datos no se han eliminados");
            }

            cargar();
        }

        private void btnSalirCategoria_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gridDatosCategoria_Click(object sender, EventArgs e)
        {
            this.txtIDCategoria.Text = this.gridDatosCategoria.SelectedRows[0].Cells[0].Value.ToString();
            this.txtNombreCategoria.Text = this.gridDatosCategoria.SelectedRows[0].Cells[1].Value.ToString();
        }
    }
}
