﻿namespace Henry_Orellana_Biblioteca2022
{
    partial class Frm_autores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_autores));
            this.btnSalirAutor = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gridDatosAutor = new System.Windows.Forms.DataGridView();
            this.btnModificarAutor = new System.Windows.Forms.Button();
            this.btnEliminarAutor = new System.Windows.Forms.Button();
            this.btnAgregarAutor = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTelefonoAutor = new System.Windows.Forms.TextBox();
            this.txtNacioAutor = new System.Windows.Forms.TextBox();
            this.txtApellidoAutor = new System.Windows.Forms.TextBox();
            this.txtNombreAutor = new System.Windows.Forms.TextBox();
            this.txtIDAutor = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosAutor)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSalirAutor
            // 
            this.btnSalirAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnSalirAutor.Location = new System.Drawing.Point(364, 333);
            this.btnSalirAutor.Name = "btnSalirAutor";
            this.btnSalirAutor.Size = new System.Drawing.Size(79, 33);
            this.btnSalirAutor.TabIndex = 74;
            this.btnSalirAutor.Text = "Salir";
            this.btnSalirAutor.UseVisualStyleBackColor = true;
            this.btnSalirAutor.Click += new System.EventHandler(this.btnSalirAutor_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gridDatosAutor);
            this.groupBox2.Location = new System.Drawing.Point(442, 48);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(505, 304);
            this.groupBox2.TabIndex = 73;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tabla producto en la BD";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // gridDatosAutor
            // 
            this.gridDatosAutor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDatosAutor.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.gridDatosAutor.Location = new System.Drawing.Point(6, 19);
            this.gridDatosAutor.MultiSelect = false;
            this.gridDatosAutor.Name = "gridDatosAutor";
            this.gridDatosAutor.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridDatosAutor.Size = new System.Drawing.Size(505, 262);
            this.gridDatosAutor.TabIndex = 0;
            this.gridDatosAutor.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridDatosAutor_CellContentClick);
            this.gridDatosAutor.Click += new System.EventHandler(this.gridDatosAutor_Click);
            // 
            // btnModificarAutor
            // 
            this.btnModificarAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnModificarAutor.Location = new System.Drawing.Point(124, 333);
            this.btnModificarAutor.Name = "btnModificarAutor";
            this.btnModificarAutor.Size = new System.Drawing.Size(100, 33);
            this.btnModificarAutor.TabIndex = 72;
            this.btnModificarAutor.Text = "Modificar";
            this.btnModificarAutor.UseVisualStyleBackColor = true;
            this.btnModificarAutor.Click += new System.EventHandler(this.btnModificarAutor_Click);
            // 
            // btnEliminarAutor
            // 
            this.btnEliminarAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnEliminarAutor.Location = new System.Drawing.Point(248, 333);
            this.btnEliminarAutor.Name = "btnEliminarAutor";
            this.btnEliminarAutor.Size = new System.Drawing.Size(89, 33);
            this.btnEliminarAutor.TabIndex = 71;
            this.btnEliminarAutor.Text = "Eliminar";
            this.btnEliminarAutor.UseVisualStyleBackColor = true;
            this.btnEliminarAutor.Click += new System.EventHandler(this.btnEliminarAutor_Click);
            // 
            // btnAgregarAutor
            // 
            this.btnAgregarAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnAgregarAutor.Location = new System.Drawing.Point(11, 333);
            this.btnAgregarAutor.Name = "btnAgregarAutor";
            this.btnAgregarAutor.Size = new System.Drawing.Size(91, 33);
            this.btnAgregarAutor.TabIndex = 70;
            this.btnAgregarAutor.Text = "Agregar";
            this.btnAgregarAutor.UseVisualStyleBackColor = true;
            this.btnAgregarAutor.Click += new System.EventHandler(this.btnAgregarAutor_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTelefonoAutor);
            this.groupBox1.Controls.Add(this.txtNacioAutor);
            this.groupBox1.Controls.Add(this.txtApellidoAutor);
            this.groupBox1.Controls.Add(this.txtNombreAutor);
            this.groupBox1.Controls.Add(this.txtIDAutor);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(28, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(403, 287);
            this.groupBox1.TabIndex = 69;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos de producto";
            // 
            // txtTelefonoAutor
            // 
            this.txtTelefonoAutor.Location = new System.Drawing.Point(177, 244);
            this.txtTelefonoAutor.Name = "txtTelefonoAutor";
            this.txtTelefonoAutor.Size = new System.Drawing.Size(100, 20);
            this.txtTelefonoAutor.TabIndex = 16;
            // 
            // txtNacioAutor
            // 
            this.txtNacioAutor.Location = new System.Drawing.Point(177, 188);
            this.txtNacioAutor.Name = "txtNacioAutor";
            this.txtNacioAutor.Size = new System.Drawing.Size(184, 20);
            this.txtNacioAutor.TabIndex = 15;
            // 
            // txtApellidoAutor
            // 
            this.txtApellidoAutor.Location = new System.Drawing.Point(177, 132);
            this.txtApellidoAutor.Name = "txtApellidoAutor";
            this.txtApellidoAutor.Size = new System.Drawing.Size(184, 20);
            this.txtApellidoAutor.TabIndex = 14;
            // 
            // txtNombreAutor
            // 
            this.txtNombreAutor.Location = new System.Drawing.Point(177, 85);
            this.txtNombreAutor.Name = "txtNombreAutor";
            this.txtNombreAutor.Size = new System.Drawing.Size(184, 20);
            this.txtNombreAutor.TabIndex = 13;
            // 
            // txtIDAutor
            // 
            this.txtIDAutor.Enabled = false;
            this.txtIDAutor.Location = new System.Drawing.Point(177, 37);
            this.txtIDAutor.Name = "txtIDAutor";
            this.txtIDAutor.Size = new System.Drawing.Size(100, 20);
            this.txtIDAutor.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(32, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Telefono:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(32, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Nacionalidad:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(32, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Apellidos:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(32, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Nombre De Autor:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(93, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "ID_Autor:";
            // 
            // Frm_autores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(959, 450);
            this.Controls.Add(this.btnSalirAutor);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnModificarAutor);
            this.Controls.Add(this.btnEliminarAutor);
            this.Controls.Add(this.btnAgregarAutor);
            this.Controls.Add(this.groupBox1);
            this.Name = "Frm_autores";
            this.Text = "Frm_autores";
            this.Load += new System.EventHandler(this.Frm_autores_Load);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridDatosAutor)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSalirAutor;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView gridDatosAutor;
        private System.Windows.Forms.Button btnModificarAutor;
        private System.Windows.Forms.Button btnEliminarAutor;
        private System.Windows.Forms.Button btnAgregarAutor;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtTelefonoAutor;
        private System.Windows.Forms.TextBox txtNacioAutor;
        private System.Windows.Forms.TextBox txtApellidoAutor;
        private System.Windows.Forms.TextBox txtNombreAutor;
        private System.Windows.Forms.TextBox txtIDAutor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}