﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Henry_Orellana_Biblioteca2022
{
    public partial class Frm_autores : Form
    {
        Clases.Transacciones T = new Clases.Transacciones();
        Clases.Autores A = new Clases.Autores();
        public Frm_autores()
        {
            InitializeComponent();
        }

        private void btnAgregarAutor_Click(object sender, EventArgs e)
        {
            A.nombre_autor = txtNombreAutor.Text;
            A.apellidos = txtApellidoAutor.Text;
            A.nacionalidad = txtNacioAutor.Text;
            A.telefono = txtTelefonoAutor.Text;
            T.insertar(A, "Autores");
            cargar();
        }

        private void btnModificarAutor_Click(object sender, EventArgs e)
        {
            A.nombre_autor = txtNombreAutor.Text;
            A.apellidos = txtApellidoAutor.Text;
            A.nacionalidad = txtNacioAutor.Text;
            A.telefono = txtTelefonoAutor.Text;
            A.id_autor = int.Parse(txtIDAutor.Text); //IMPORTANTE
            T.modificar(A, "Autores");
            cargar();
        }

        private void btnEliminarAutor_Click(object sender, EventArgs e)
        {
            int fila;
            string valor;
            bool intento;
            fila = gridDatosAutor.CurrentRow.Index;
            gridDatosAutor.Rows[fila].Selected = true;

            valor = gridDatosAutor.SelectedCells[0].Value.ToString();

            if (MessageBox.Show("¿Seguro que quieres eliminar el registro?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                intento = T.eliminar("Autores", "id_autor", valor);
                if (intento == true)
                {
                    MessageBox.Show("Los datos se han eliminado");
                }
            }

            else
            {
                MessageBox.Show("Los datos no se han eliminados");
            }

            cargar();
        }

        private void btnSalirAutor_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Frm_autores_Load(object sender, EventArgs e)
        {
            cargar();
        }
        private void cargar()
        {
            gridDatosAutor.DataSource = T.consultar("Autores");
        }

        private void gridDatosAutor_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void gridDatosAutor_Click(object sender, EventArgs e)
        {
            this.txtIDAutor.Text = this.gridDatosAutor.SelectedRows[0].Cells[0].Value.ToString();
            this.txtNombreAutor.Text = this.gridDatosAutor.SelectedRows[0].Cells[1].Value.ToString();
            this.txtApellidoAutor.Text = this.gridDatosAutor.SelectedRows[0].Cells[2].Value.ToString();
            this.txtNacioAutor.Text = this.gridDatosAutor.SelectedRows[0].Cells[3].Value.ToString();
            this.txtTelefonoAutor.Text = this.gridDatosAutor.SelectedRows[0].Cells[4].Value.ToString();
        }
    }
}
