﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContolesDeUsuario
{
    public partial class dado : UserControl
    {
        //propiedad fundamental , el valor que va tener el dado
        //atributo de ripo entero
        private int valor = 1;
        //definir propiedad que va a acceder a ese valor
        public  int Valor
        {       
            get { return valor; }
            set
            {
                if (value>= 1 && value <= 6)
                {
                    valor = value;
                    Invalidate();//se dibuja el dado
                }
                else
                {
                    MessageBox.Show("Es necesario ingresar valores en el rango 1-6");
                }
            }
        }
        //Constructor donde vamos a inicializar
        public dado()
        {
            InitializeComponent();
            Width = 100;
            Height = 100;
        }

        private void dado_Paint(object sender, PaintEventArgs e)
        {
            //método para graficar el dado
            Graphics lienzo = CreateGraphics();//obteniendo referencia

            //se dibuja el rectangulo pitandolo de negro,
            //el ancho y alto va desde la columna 0 y la fila 0, las componentes
            //las variables width y height se les resta un pixel para que queden dentro del rectangulo
            lienzo.DrawRectangle(new Pen(Color.Black), 0, 0, Width - 1, Height - 1);
            int diametro = Width / 5; //varia el cada circulo del dado
            //verificams si el valor del dado es 1, y hacemos el siguiente código para dibujar dentro 
            if (valor==1 || valor==3 || valor == 5)
            {
                //FillEllipse es para colorear
                //diametro /2 es para que el circulo se ubique al centro de nuestra componente
                lienzo.FillEllipse(new SolidBrush(Color.Red), 
                 (Width * 0.5f) + (diametro / 2), 
                 (Width * 0.5f) + (diametro / 2), 
                 diametro, diametro);

                
            }
            if (valor ==2 || valor==3 || valor== 4 || valor == 5 || valor ==6) 
            {
                //en este caso cambian las coordenadas con la variable Width
                //verificando donde ubicaremos los círculos, en ambos
                lienzo.FillEllipse(
                    new SolidBrush(Color.Red),
                    (Width * 0.25f) - (diametro / 2),
                    (Width * 0.25f) - (diametro / 2),
                     diametro,diametro
                );

                lienzo.FillEllipse(
                new SolidBrush(Color.Red),
                (Width * 0.75f) - (diametro / 2),
                (Width * 0.75f) - (diametro / 2),
                diametro,
                diametro
                );

               
            }
            if (valor == 4 || valor == 5 || valor==6)
            {
                lienzo.FillEllipse(
                  new SolidBrush(Color.Red),
                  (Width * 0.75f) - (diametro / 2),
                  (Width * 0.25f) - (diametro / 2),
                   diametro, diametro
              );

                lienzo.FillEllipse(
               new SolidBrush(Color.Red),
               (Width * 0.25f) - (diametro / 2),
               (Width * 0.75f) - (diametro / 2),
               diametro,
               diametro
               );
            }
            if (valor== 6)
            {
                lienzo.FillEllipse(
                new SolidBrush(Color.Red),
                (Width * 0.25f) - (diametro / 2),
                (Width * 0.50f) - (diametro / 2),
                 diametro, diametro
                 );

                lienzo.FillEllipse(
            new SolidBrush(Color.Red),
            (Width * 0.75f) - (diametro / 2),
            (Width * 0.50f) - (diametro / 2),
            diametro,
            diametro
            );
            }




        }
    }
}
