﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlDeUsuario
{
    public partial class dado : UserControl
    {
        //Propiedad fundamental, el valor que va a tener el dado
        //Atributo de  tipo entero
        private int valor = 1;
        //Definir propiedad que va a acceder a ese valor
        public int Valor
        {
            get 
            {
                return valor;
            }
            set
            {
                if (value >=1 && value <= 6)
                {
                    valor = value;
                    Invalidate();//Se dibuja el dado
                }
                else
                {
                    MessageBox.Show("Es necesario ingresar valores en el rango 1-6");
                }
            }
        }

        //Constructor donde vamos a inicializar
        public dado()
        {
            InitializeComponent();
            Width = 100;
            Height = 100;
        }
        private void dado_Paint(object sender, PaintEventArgs e)
        {
            //método para  graficar el dado
            Graphics lienzo = CreateGraphics();//Obteniendo referencia
            //Se  dibuja el rectángulo pitándolo de negro,
            //el ancho y alto va desde la columna 0 y fila 0, las componentes
            //las variables Width y Height se les resta un pixel para que queden dentro del rectángulo
            lienzo.DrawRectangle(new Pen(Color.Black), 0, 0, Width - 1, Height - 1);
            int diametro = Width / 5;//Varía en cada circulo del dado
            //Verificamos si el valor del dado es 1, y hhacemos el siguiente código para dibujar dentro
            if (valor==1 || valor==3 || valor == 5)
            {
                //FillEllipse es para colorear
                //diametro/2 es para que el circulo se ubique al centro de nuestra componente
                lienzo.FillEllipse(
                    new SolidBrush(Color.Red),
                    (Width * 0.5f) - (diametro / 2),
                    (Width * 0.5f) - (diametro / 2),
                    diametro,
                    diametro
                    );
            }
            if (valor==2 || valor ==3 || valor == 4 || valor  ==5 || valor ==6)
            {
                //en este caso cambian las coordenadas con la variable Width
                //verificamos donde ubicaremos los circulos, en ambos
                lienzo.FillEllipse(
                    new SolidBrush(Color.Red),
                    (Width * 0.25f) - (diametro / 2),
                    (Width * 0.25f) - (diametro / 2),
                    diametro,
                    diametro
                    );

                lienzo.FillEllipse(
                    new SolidBrush(Color.Red),
                    (Width * 0.75f) - (diametro / 2),
                    (Width * 0.75f) - (diametro / 2),
                    diametro,
                    diametro
                    );

            }
            if (valor == 4 || valor ==5 || valor==6)
            { 
                lienzo.FillEllipse(
                    new SolidBrush(Color.Red),
                    (Width * 0.75f) - (diametro / 2),// columna 0.75
                    (Width * 0.25f) - (diametro / 2),// fila 0.25
                    diametro,
                    diametro
                    );

                lienzo.FillEllipse(
                    new SolidBrush(Color.Red),
                    (Width * 0.25f) - (diametro / 2),// columna 0.75
                    (Width * 0.75f) - (diametro / 2),// fila 0.25
                    diametro,
                    diametro
                    );

            }
            if (valor ==6)
            {
                
                lienzo.FillEllipse(
                    new SolidBrush(Color.Red),
                    (Width * 0.25f) - (diametro / 2),//columna 0.25
                    (Width * 0.50f) - (diametro / 2),//fila 0.50
                    diametro,
                    diametro
                    );

                lienzo.FillEllipse(
                    new SolidBrush(Color.Red),
                    (Width * 0.75f) - (diametro / 2),//columna 0.75
                    (Width * 0.50f) - (diametro / 2),//fila 0.50
                    diametro,
                    diametro
                    );

            }
          
           

        }

        private void dado_Resize(object sender, EventArgs e)
        {
            Width = Height;
            //con esto logramos que siempre sea un cuadrado
            // porque un dado es cuadrado
            //y si su anchura y altura son iguales
            //una vez cambiando valores, tomarían el mismo
        }
    }
}
