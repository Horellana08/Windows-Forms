﻿namespace ControlDeUsuario
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dado1 = new ControlDeUsuario.dado();
            this.dado2 = new ControlDeUsuario.dado();
            this.dado3 = new ControlDeUsuario.dado();
            this.btnSortear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dado1
            // 
            this.dado1.Location = new System.Drawing.Point(53, 101);
            this.dado1.Name = "dado1";
            this.dado1.Size = new System.Drawing.Size(130, 130);
            this.dado1.TabIndex = 0;
            this.dado1.Valor = 6;
            // 
            // dado2
            // 
            this.dado2.Location = new System.Drawing.Point(311, 101);
            this.dado2.Name = "dado2";
            this.dado2.Size = new System.Drawing.Size(130, 130);
            this.dado2.TabIndex = 1;
            this.dado2.Valor = 1;
            // 
            // dado3
            // 
            this.dado3.Location = new System.Drawing.Point(558, 101);
            this.dado3.Name = "dado3";
            this.dado3.Size = new System.Drawing.Size(130, 130);
            this.dado3.TabIndex = 2;
            this.dado3.Valor = 1;
            // 
            // btnSortear
            // 
            this.btnSortear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnSortear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSortear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSortear.Location = new System.Drawing.Point(311, 267);
            this.btnSortear.Name = "btnSortear";
            this.btnSortear.Size = new System.Drawing.Size(130, 59);
            this.btnSortear.TabIndex = 3;
            this.btnSortear.Text = "Sortear";
            this.btnSortear.UseVisualStyleBackColor = false;
            this.btnSortear.Click += new System.EventHandler(this.btnSortear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(777, 381);
            this.Controls.Add(this.btnSortear);
            this.Controls.Add(this.dado3);
            this.Controls.Add(this.dado2);
            this.Controls.Add(this.dado1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private dado dado1;
        private dado dado2;
        private dado dado3;
        private System.Windows.Forms.Button btnSortear;
    }
}

